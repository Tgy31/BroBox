//
//  main.m
//  GFPlaceholderView
//
//  Created by Giovanni Filaferro on 28/12/14.
//  Copyright (c) 2014 Giovanni Filaferro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
