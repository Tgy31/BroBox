//
//  ViewController.h
//  GFPlaceholderView
//
//  Created by Giovanni Filaferro on 28/12/14.
//  Copyright (c) 2014 Giovanni Filaferro. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GFPlaceholderView.h"

@interface ViewController : UIViewController


@end

