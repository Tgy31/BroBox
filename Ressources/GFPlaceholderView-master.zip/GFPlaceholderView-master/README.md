GFPlaceholderView
=================

Little library for place holding. It is useful for networking to show loading and displaying errors like Apple Apps!

<img src="image.gif" alt="screenshot" />