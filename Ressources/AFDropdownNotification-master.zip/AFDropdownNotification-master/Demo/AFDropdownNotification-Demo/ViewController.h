//
//  ViewController.h
//  AFDropdownNotification-Demo
//
//  Created by Alvaro Franco on 15/12/14.
//  Copyright (c) 2014 AluanaLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFDropdownNotification.h"

@interface ViewController : UIViewController <AFDropdownNotificationDelegate>


@end

