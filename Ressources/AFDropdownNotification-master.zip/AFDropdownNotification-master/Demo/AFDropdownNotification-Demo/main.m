//
//  main.m
//  AFDropdownNotification-Demo
//
//  Created by Alvaro Franco on 15/12/14.
//  Copyright (c) 2014 AluanaLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
